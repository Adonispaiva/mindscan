# Este arquivo faz parte da reconstrução do MindScan.
# Conteúdo real será preenchido automaticamente pelo Leo Vinci.
