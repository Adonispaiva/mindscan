import React from "react";

function App() {
  return (
    <div className="w-full min-h-screen bg-gray-50 flex items-center justify-center">
      <h1 className="text-3xl font-bold text-gray-800">MindScan Frontend</h1>
    </div>
  );
}

export default App;
